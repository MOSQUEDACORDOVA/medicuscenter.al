<?php

//english lang

//nav
$lang['lang-eng'] = 'Inglese';
$lang['lang-fre'] = 'Francese';
$lang['lang-ger'] = 'Tedesco';
$lang['lang-it'] = 'Italiano';

//index 
$lang['index-title'] = 'Italian Language';
$lang['index-welcome'] = 'Benvenuto nella demo della lingua';
$lang['index-text-1'] = "Lorem Ipsum è semplicemente un testo fittizio dell'industria della stampa e della composizione. Lorem Ipsum è stato il testo fittizio standard del settore sin dal 1500, quando uno stampatore sconosciuto prese una cambusa di caratteri e li rimescolava per creare un testo campione. È sopravvissuto non solo a cinque secoli, ma anche al salto nella composizione elettronica, rimanendo sostanzialmente immutato. È stato reso popolare negli anni '60 con il rilascio di fogli Letraset contenenti passaggi di Lorem Ipsum e, più recentemente, con software di desktop publishing come Aldus PageMaker che include versioni di Lorem Ipsum.";
$lang['demo'] = 'Torna al tutorial';
?>